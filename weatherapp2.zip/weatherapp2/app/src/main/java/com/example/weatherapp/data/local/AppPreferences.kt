package com.example.weatherapp.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "weather_prefs")

class AppPreferences(private val context: Context) {

    private object Keys {
        val UNITS = stringPreferencesKey("units") // "C" or "F"
        val HISTORY = stringPreferencesKey("history") // "Almaty|Astana"
        val LAST_CACHE_JSON = stringPreferencesKey("last_cache_json")
        val LAST_CITY_DISPLAY = stringPreferencesKey("last_city_display")
    }

    val unitsFlow: Flow<String> = context.dataStore.data.map { it[Keys.UNITS] ?: "C" }

    val historyFlow: Flow<List<String>> = context.dataStore.data.map { prefs ->
        val raw = prefs[Keys.HISTORY].orEmpty()
        if (raw.isBlank()) emptyList()
        else raw.split("|").filter { it.isNotBlank() }
    }

    suspend fun getUnits(): String = unitsFlow.first()

    suspend fun setUnits(units: String) {
        context.dataStore.edit { it[Keys.UNITS] = units }
    }

    suspend fun addHistory(city: String) {
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.HISTORY].orEmpty()
            val list = if (current.isBlank()) mutableListOf() else current.split("|").toMutableList()

            list.removeAll { it.equals(city, ignoreCase = true) }
            list.add(0, city)

            prefs[Keys.HISTORY] = list.take(8).joinToString("|")
        }
    }

    suspend fun saveCache(cityDisplay: String, json: String) {
        context.dataStore.edit {
            it[Keys.LAST_CITY_DISPLAY] = cityDisplay
            it[Keys.LAST_CACHE_JSON] = json
        }
    }

    suspend fun readCacheJson(): String =
        context.dataStore.data.first()[Keys.LAST_CACHE_JSON].orEmpty()

    suspend fun readCacheCityDisplay(): String =
        context.dataStore.data.first()[Keys.LAST_CITY_DISPLAY].orEmpty()
}
