package com.example.weatherapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.example.weatherapp.vm.WeatherViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherScreen(vm: WeatherViewModel) {
    val state by vm.state.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Weather") },
                actions = {
                    TextButton(onClick = { vm.toggleUnits() }) {
                        Text(if (state.units == "C") "°C" else "°F")
                    }
                }
            )
        }
    ) { padding ->

        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // Search + history
            var expanded by remember { mutableStateOf(false) }

            ExposedDropdownMenuBox(
                expanded = expanded && state.history.isNotEmpty(),
                onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    value = state.query,
                    onValueChange = {
                        vm.onQueryChange(it)
                        expanded = true
                    },
                    label = { Text("City") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { vm.fetch() }),
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }
                )

                ExposedDropdownMenu(
                    expanded = expanded && state.history.isNotEmpty(),
                    onDismissRequest = { expanded = false }
                ) {
                    state.history.forEach { item ->
                        DropdownMenuItem(
                            text = { Text(item) },
                            onClick = {
                                expanded = false
                                vm.pickHistory(item)
                            }
                        )
                    }
                }
            }

            Button(
                onClick = { vm.fetch() },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Search")
            }

            if (state.isLoading) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator()
                }
            }

            state.error?.let {
                AssistChip(onClick = {}, label = { Text(it) })
            }

            state.weather?.let { bundle ->
                if (bundle.isOffline) {
                    Text("OFFLINE MODE: showing cached data", color = MaterialTheme.colorScheme.error)
                }

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(bundle.current.city, style = MaterialTheme.typography.titleLarge)
                        Text("${bundle.current.temperature} ${bundle.current.unitSymbol}", style = MaterialTheme.typography.headlineMedium)
                        Text(bundle.current.condition)

                        bundle.current.feelsLike?.let { Text("Feels like: $it ${bundle.current.unitSymbol}") }
                        bundle.current.humidity?.let { Text("Humidity: $it%") }
                        Text("Wind: ${bundle.current.windKmh} km/h")
                        Text("Last update: ${bundle.current.lastUpdateIso}", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("3-day forecast", style = MaterialTheme.typography.titleMedium)
                        bundle.forecast.forEach { d ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text(d.dateIso)
                                    Text(d.condition, style = MaterialTheme.typography.bodySmall)
                                }
                                Text("${d.minTemp}${bundle.current.unitSymbol} / ${d.maxTemp}${bundle.current.unitSymbol}")
                            }
                        }
                    }
                }
            }
        }
    }
}
