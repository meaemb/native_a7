package com.example.weatherapp.vm

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.weatherapp.data.local.AppPreferences
import com.example.weatherapp.data.repository.WeatherRepository
import com.example.weatherapp.data.repository.WeatherRepositoryImpl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class WeatherViewModel(
    private val prefs: AppPreferences,
    private val repo: WeatherRepository = WeatherRepositoryImpl(prefs)
) : ViewModel() {

    private val _state = MutableStateFlow(WeatherUiState())
    val state: StateFlow<WeatherUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            prefs.unitsFlow.collectLatest { u ->
                _state.update { it.copy(units = u) }
            }
        }
        viewModelScope.launch {
            prefs.historyFlow.collectLatest { h ->
                _state.update { it.copy(history = h) }
            }
        }
    }

    fun onQueryChange(text: String) {
        _state.update { it.copy(query = text, error = null) }
    }

    fun pickHistory(city: String) {
        _state.update { it.copy(query = city, error = null) }
        fetch()
    }

    fun toggleUnits() {
        viewModelScope.launch {
            val newUnits = if (_state.value.units == "C") "F" else "C"
            prefs.setUnits(newUnits)
            if (_state.value.weather != null) fetch()
        }
    }

    fun fetch() {
        val city = _state.value.query.trim()
        if (city.isBlank()) {
            _state.update { it.copy(error = "Please enter a city name.") }
            return
        }

        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }

            val units = _state.value.units

            val result = runCatching {
                repo.fetchByCity(city, units)
            }.recoverCatching { e ->
                // if network fails -> try cache
                val cached = repo.loadCached(units)
                cached ?: throw e
            }

            result.onSuccess { bundle ->
                _state.update { it.copy(isLoading = false, weather = bundle, error = null) }
            }.onFailure { e ->
                val msg = when (e) {
                    is WeatherRepositoryImpl.CityNotFoundException -> "City not found."
                    is IllegalArgumentException -> "Please enter a city name."
                    else -> "Network/API error. Try again."
                }
                _state.update { it.copy(isLoading = false, error = msg) }
            }
        }
    }
}
