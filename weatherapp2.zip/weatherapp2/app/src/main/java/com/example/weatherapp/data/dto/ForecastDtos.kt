package com.example.weatherapp.data.dto

import com.google.gson.annotations.SerializedName

data class ForecastResponseDto(
    @SerializedName("current_weather") val currentWeather: CurrentWeatherDto?,
    val hourly: HourlyDto?,
    val daily: DailyDto?
)

data class CurrentWeatherDto(
    val time: String,
    val temperature: Double,
    @SerializedName("windspeed") val windSpeed: Double,
    @SerializedName("weathercode") val weatherCode: Int
)

data class HourlyDto(
    val time: List<String>?,
    @SerializedName("relativehumidity_2m") val humidity: List<Int>?,
    @SerializedName("apparent_temperature") val apparentTemperature: List<Double>?
)

data class DailyDto(
    val time: List<String>?,
    @SerializedName("temperature_2m_min") val tempMin: List<Double>?,
    @SerializedName("temperature_2m_max") val tempMax: List<Double>?,
    @SerializedName("weathercode") val weatherCode: List<Int>?
)
