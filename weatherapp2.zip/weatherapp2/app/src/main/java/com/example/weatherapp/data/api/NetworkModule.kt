package com.example.weatherapp.data.api

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object NetworkModule {

    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .callTimeout(12, TimeUnit.SECONDS)
        .build()

    private fun retrofit(baseUrl: String): Retrofit =
        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(okHttp)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    val geocodingApi: OpenMeteoGeocodingApi =
        retrofit("https://geocoding-api.open-meteo.com/")
            .create(OpenMeteoGeocodingApi::class.java)

    val forecastApi: OpenMeteoApi =
        retrofit("https://api.open-meteo.com/")
            .create(OpenMeteoApi::class.java)
}
