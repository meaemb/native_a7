package com.example.weatherapp.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography()
