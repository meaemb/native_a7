package com.example.weatherapp.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.example.weatherapp.data.local.AppPreferences
import com.example.weatherapp.ui.screens.WeatherScreen
import com.example.weatherapp.ui.theme.WeatherAppTheme
import com.example.weatherapp.vm.WeatherViewModel

@Composable
fun WeatherApp() {
    val context = LocalContext.current
    val prefs = remember { AppPreferences(context) }
    val vm = remember { WeatherViewModel(prefs) }

    WeatherAppTheme {
        WeatherScreen(vm)
    }
}
