package com.example.weatherapp.data.repository

import com.example.weatherapp.domain.WeatherBundle

interface WeatherRepository {
    suspend fun fetchByCity(city: String, units: String): WeatherBundle
    suspend fun loadCached(units: String): WeatherBundle?
}
