package com.example.weatherapp.ui.theme

import androidx.compose.ui.graphics.Color

val BluePrimary = Color(0xFF2196F3)
val BlueSecondary = Color(0xFF90CAF9)
val BlueDark = Color(0xFF1976D2)
