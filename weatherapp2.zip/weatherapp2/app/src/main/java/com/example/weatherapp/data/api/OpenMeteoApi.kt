package com.example.weatherapp.data.api

import com.example.weatherapp.data.dto.ForecastResponseDto
import retrofit2.http.GET
import retrofit2.http.Query

interface OpenMeteoApi {

    @GET("v1/forecast")
    suspend fun getForecast(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,

        @Query("current_weather") currentWeather: Boolean = true,

        // hourly -> humidity + feels-like (apparent temp)
        @Query("hourly") hourly: String = "relativehumidity_2m,apparent_temperature",

        // daily -> 3-day forecast
        @Query("daily") daily: String = "temperature_2m_max,temperature_2m_min,weathercode",

        @Query("timezone") timezone: String = "auto",
        @Query("forecast_days") forecastDays: Int = 3,

        @Query("temperature_unit") temperatureUnit: String, // "celsius" / "fahrenheit"
        @Query("windspeed_unit") windspeedUnit: String = "kmh"
    ): ForecastResponseDto
}
