package com.example.weatherapp.data.repository

import com.example.weatherapp.data.api.NetworkModule
import com.example.weatherapp.data.dto.ForecastResponseDto
import com.example.weatherapp.data.local.AppPreferences
import com.example.weatherapp.domain.CurrentWeather
import com.example.weatherapp.domain.DailyForecast
import com.example.weatherapp.domain.WeatherBundle
import com.google.gson.Gson

class WeatherRepositoryImpl(
    private val prefs: AppPreferences
) : WeatherRepository {

    private val gson = Gson()

    override suspend fun fetchByCity(city: String, units: String): WeatherBundle {
        val q = city.trim()
        if (q.isBlank()) throw IllegalArgumentException("Empty city")

        val geo = NetworkModule.geocodingApi.searchCity(q)
        val first = geo.results?.firstOrNull() ?: throw CityNotFoundException()

        val cityDisplay = listOfNotNull(first.name, first.admin1, first.country).joinToString(", ")

        val tempUnit = if (units == "F") "fahrenheit" else "celsius"
        val dto = NetworkModule.forecastApi.getForecast(
            latitude = first.latitude,
            longitude = first.longitude,
            temperatureUnit = tempUnit
        )

        val bundle = dto.toDomain(cityDisplay, units, isOffline = false)

        // save cache
        prefs.addHistory(q)
        prefs.saveCache(cityDisplay, gson.toJson(dto))

        return bundle
    }

    override suspend fun loadCached(units: String): WeatherBundle? {
        val json = prefs.readCacheJson()
        if (json.isBlank()) return null

        val cityDisplay = prefs.readCacheCityDisplay().ifBlank { "Cached city" }
        val dto = runCatching { gson.fromJson(json, ForecastResponseDto::class.java) }.getOrNull() ?: return null

        return dto.toDomain(cityDisplay, units, isOffline = true)
    }

    private fun ForecastResponseDto.toDomain(cityDisplay: String, units: String, isOffline: Boolean): WeatherBundle {
        val cw = currentWeather ?: throw IllegalStateException("No current weather")

        val unitSymbol = if (units == "F") "°F" else "°C"

        // find humidity + feelsLike by matching time index
        val idx = hourly?.time?.indexOf(cw.time) ?: -1
        val humidity = if (idx >= 0) hourly?.humidity?.getOrNull(idx) else null
        val feels = if (idx >= 0) hourly?.apparentTemperature?.getOrNull(idx) else null

        val current = CurrentWeather(
            city = cityDisplay,
            temperature = cw.temperature,
            condition = WeatherCodeMapper.toText(cw.weatherCode),
            feelsLike = feels,
            humidity = humidity,
            windKmh = cw.windSpeed,
            lastUpdateIso = cw.time,
            unitSymbol = unitSymbol
        )

        val dates = daily?.time.orEmpty()
        val mins = daily?.tempMin.orEmpty()
        val maxs = daily?.tempMax.orEmpty()
        val codes = daily?.weatherCode.orEmpty()

        val forecast = dates.mapIndexedNotNull { i, d ->
            val min = mins.getOrNull(i) ?: return@mapIndexedNotNull null
            val max = maxs.getOrNull(i) ?: return@mapIndexedNotNull null
            val code = codes.getOrNull(i) ?: -1
            DailyForecast(
                dateIso = d,
                minTemp = min,
                maxTemp = max,
                condition = WeatherCodeMapper.toText(code)
            )
        }.take(3)

        return WeatherBundle(current = current, forecast = forecast, isOffline = isOffline)
    }

    class CityNotFoundException : Exception()
}
