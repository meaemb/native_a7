package com.example.weatherapp.data.dto

import com.google.gson.annotations.SerializedName

data class GeocodingResponseDto(
    val results: List<GeocodingResultDto>?
)

data class GeocodingResultDto(
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val country: String?,
    @SerializedName("admin1") val admin1: String?
)
