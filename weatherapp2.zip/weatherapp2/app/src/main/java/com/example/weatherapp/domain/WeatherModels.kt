package com.example.weatherapp.domain

data class CurrentWeather(
    val city: String,
    val temperature: Double,
    val condition: String,
    val feelsLike: Double?,
    val humidity: Int?,
    val windKmh: Double,
    val lastUpdateIso: String,
    val unitSymbol: String
)

data class DailyForecast(
    val dateIso: String,
    val minTemp: Double,
    val maxTemp: Double,
    val condition: String
)

data class WeatherBundle(
    val current: CurrentWeather,
    val forecast: List<DailyForecast>,
    val isOffline: Boolean
)
