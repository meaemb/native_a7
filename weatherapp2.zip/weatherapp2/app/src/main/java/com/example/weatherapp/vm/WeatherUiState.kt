package com.example.weatherapp.vm

import com.example.weatherapp.domain.WeatherBundle

data class WeatherUiState(
    val query: String = "",
    val units: String = "C",
    val history: List<String> = emptyList(),

    val isLoading: Boolean = false,
    val weather: WeatherBundle? = null,
    val error: String? = null
)
